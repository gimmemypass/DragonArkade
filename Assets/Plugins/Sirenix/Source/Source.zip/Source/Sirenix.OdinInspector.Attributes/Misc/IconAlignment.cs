//-----------------------------------------------------------------------
// <copyright file="IconAlignment.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace Sirenix.OdinInspector
{
    public enum IconAlignment
    {
        LeftOfText,
        RightOfText,
        LeftEdge,
        RightEdge
    }
}