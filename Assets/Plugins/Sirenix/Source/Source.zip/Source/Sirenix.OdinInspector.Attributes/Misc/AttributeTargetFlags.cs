//-----------------------------------------------------------------------
// <copyright file="AttributeTargetFlags.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace Sirenix.OdinInspector
{
    using System;

    /// <summary>
    /// Not yet documented.
    /// </summary>
    public static class AttributeTargetFlags
    {
        /// <summary>
        /// Not yet documented.
        /// </summary>
        public const AttributeTargets Default = AttributeTargets.All;
    }
}