//-----------------------------------------------------------------------
// <copyright file="PreviewFieldAttributeDrawer.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
namespace Sirenix.OdinInspector.Editor.Drawers
{
    using Sirenix.Utilities.Editor;
    using UnityEditor;
    using UnityEngine;
    using ValueResolvers;

    /// <summary>
    /// Draws properties marked with <see cref="PreviewFieldAttribute"/> as a square ObjectField which renders a preview for UnityEngine.Object types.
    /// This object field also adds support for drag and drop, dragging an object to another square object field, swaps the values.
    /// If you hold down control while letting go it will replace the value, And you can control + click the object field to quickly delete the value it holds.
    /// </summary>

    [AllowGUIEnabledForReadonly]
    public sealed class PreviewFieldAttributeDrawer<T> : OdinAttributeDrawer<PreviewFieldAttribute, T>
        where T : UnityEngine.Object
    {
        private ValueResolver<UnityEngine.Object> previewResolver;

        protected override void Initialize()
        {
            this.previewResolver = ValueResolver.Get<UnityEngine.Object>(this.Property, this.Attribute.PreviewGetter);
        }

        /// <summary>
        /// Draws the property.
        /// </summary>
        protected override void DrawPropertyLayout(GUIContent label)
        {
            if (this.Attribute.PreviewGetterHasValue && this.previewResolver.HasError)
            {
                this.previewResolver.DrawError();
                this.CallNextDrawer(label);
                return;
            }

            EditorGUI.BeginChangeCheck();

            ObjectFieldAlignment alignment;

            if (this.Attribute.AlignmentHasValue)
            {
                alignment = (ObjectFieldAlignment)this.Attribute.Alignment;
            }
            else
            {
                alignment = GeneralDrawerConfig.Instance.SquareUnityObjectAlignment;
            }

            var previewHeight = this.Attribute.Height == 0
                ? GeneralDrawerConfig.Instance.SquareUnityObjectFieldHeight
                : this.Attribute.Height;

            Texture previewTexture;

            // The user provided a preview so try to get it.
            if (this.Attribute.PreviewGetterHasValue)
            {
                var resolvedPreview = this.previewResolver.GetValue();
                previewTexture = resolvedPreview == null ? null : GUIHelper.GetPreviewTexture(resolvedPreview);
            }
            // The user has not provided a preview so try to get one using the object's value.
            else
            {
                var value = this.ValueEntry.WeakSmartValue as UnityEngine.Object;
                previewTexture = value == null ? null : GUIHelper.GetPreviewTexture(value);
            }

            if (previewTexture != null)
            {
                previewTexture.filterMode = this.Attribute.FilterMode;
            }

            this.ValueEntry.WeakSmartValue = SirenixEditorFields.UnityPreviewObjectField(
                label,
                this.ValueEntry.WeakSmartValue as UnityEngine.Object,
                previewTexture,
                this.ValueEntry.BaseValueType,
                this.ValueEntry.Property.GetAttribute<AssetsOnlyAttribute>() == null,
                previewHeight,
                alignment);

            if (EditorGUI.EndChangeCheck())
            {
                this.ValueEntry.Values.ForceMarkDirty();
            }
        }
    }
}
#endif