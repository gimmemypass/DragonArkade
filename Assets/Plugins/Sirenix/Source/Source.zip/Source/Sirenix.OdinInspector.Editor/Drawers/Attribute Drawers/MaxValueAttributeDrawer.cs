//-----------------------------------------------------------------------
// <copyright file="MaxValueAttributeDrawer.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
namespace Sirenix.OdinInspector.Editor.Drawers
{
    using System;
    using Sirenix.OdinInspector;
    using Sirenix.OdinInspector.Editor.ValueResolvers;
    using Sirenix.Utilities.Editor;
    using UnityEditor;
    using UnityEngine;

    [DrawerPriority(0, 9000, 0)]
    public sealed class MaxValueAttributeDrawer<T> : OdinAttributeDrawer<MaxValueAttribute, T>
        where T : struct
    {
        private static readonly bool IsNumber = GenericNumberUtility.IsNumber(typeof(T));
        private static readonly bool IsVector = GenericNumberUtility.IsVector(typeof(T));

        private ValueResolver<double> maxValueGetter;

        public override bool CanDrawTypeFilter(Type type)
        {
            return IsNumber || IsVector;
        }

        protected override void Initialize()
        {
            this.maxValueGetter = ValueResolver.Get<double>(this.Property, this.Attribute.Expression, this.Attribute.MaxValue);
        }

        protected override void DrawPropertyLayout(GUIContent label)
        {
            if (this.maxValueGetter.HasError)
            {
                SirenixEditorGUI.ErrorMessageBox(this.maxValueGetter.ErrorMessage);
                this.CallNextDrawer(label);
            }
            else
            {
                EditorGUI.BeginChangeCheck();
                this.CallNextDrawer(label);
                if (EditorGUI.EndChangeCheck())
                {
                    T value = this.ValueEntry.SmartValue;
                    var max = this.maxValueGetter.GetValue();

                    if (!GenericNumberUtility.NumberIsInRange(value, double.MinValue, max))
                    {
                        this.ValueEntry.SmartValue = GenericNumberUtility.Clamp(value, double.MinValue, max);
                    }
                }
            }
        }
    }
}
#endif