//-----------------------------------------------------------------------
// <copyright file="QueueResolver.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
namespace Sirenix.OdinInspector.Editor
{
    using Sirenix.Serialization;
    using Sirenix.Utilities.Editor;
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class QueueResolver<TCollection, TElement> : BaseOrderedCollectionResolver<TCollection>
        where TCollection : Queue<TElement>
    {
        private Dictionary<TCollection, TElement[]> elementsArrays = new Dictionary<TCollection, TElement[]>();
        private int lastUpdateId = -1;
        private Dictionary<int, InspectorPropertyInfo> childInfos = new Dictionary<int, InspectorPropertyInfo>();

        private HashSet<TCollection> seenHashset = new HashSet<TCollection>();
        private List<TCollection> toRemoveList = new List<TCollection>();

        public override Type ElementType { get { return typeof(TElement); } }

        public override int ChildNameToIndex(string name)
        {
            return CollectionResolverUtilities.DefaultChildNameToIndex(name);
        }

        public override int ChildNameToIndex(ref StringSlice name)
        {
            return CollectionResolverUtilities.DefaultChildNameToIndex(ref name);
        }

        public override bool ChildPropertyRequiresRefresh(int index, InspectorPropertyInfo info)
        {
            return false;
        }

        public override InspectorPropertyInfo GetChildInfo(int childIndex)
        {
            if (childIndex < 0 || childIndex >= this.ChildCount)
            {
                throw new IndexOutOfRangeException();
            }

            InspectorPropertyInfo result;

            if (!this.childInfos.TryGetValue(childIndex, out result))
            {
                result = InspectorPropertyInfo.CreateValue(
                    name: CollectionResolverUtilities.DefaultIndexToChildName(childIndex),
                    order: childIndex,
                    serializationBackend: this.Property.BaseValueEntry.SerializationBackend,
                    getterSetter: new GetterSetter<TCollection, TElement>(
                        getter: (ref TCollection collection) => this.GetElement(collection, childIndex),
                        setter: (ref TCollection collection, TElement element) => this.SetElement(collection, element, childIndex)),
                    attributes: this.Property.Attributes.Where(attr => !attr.GetType().IsDefined(typeof(DontApplyToListElementsAttribute), true)).ToArray());

                this.childInfos[childIndex] = result;
            }

            return result;
        }

        protected override void Initialize()
        {
            base.Initialize();
        }

        private TElement GetElement(TCollection collection, int index)
        {
            this.EnsureUpdated();

            TElement[] elements;

            if (this.elementsArrays.TryGetValue(collection, out elements))
            {
                return elements[index];
            }

            return default(TElement);
        }

        private void SetElement(TCollection collection, TElement element, int index)
        {
            var count = collection.Count;

            using (var copyBuffer = Buffer<TElement>.Claim(count))
            {
                var array = copyBuffer.Array;
                collection.CopyTo(array, 0);

                collection.Clear();

                for (int i = 0; i < count; i++)
                {
                    if (i == index)
                    {
                        collection.Enqueue(element);
                    }
                    else
                    {
                        collection.Enqueue(array[i]);
                    }
                }
            }
        }

        private void EnsureUpdated(bool force = false)
        {
            var treeId = this.Property.Tree.UpdateID;

            if (!force && this.lastUpdateId == treeId)
            {
                return;
            }

            this.seenHashset.Clear();
            this.toRemoveList.Clear();

            this.lastUpdateId = treeId;
            var count = this.ValueEntry.ValueCount;

            for (int i = 0; i < count; i++)
            {
                var collection = this.ValueEntry.Values[i];

                if (object.ReferenceEquals(collection, null)) continue;

                this.seenHashset.Add(collection);

                TElement[] elements;

                if (!this.elementsArrays.TryGetValue(collection, out elements) || elements.Length != collection.Count)
                {
                    elements = new TElement[collection.Count];
                    this.elementsArrays[collection] = elements;
                }

                collection.CopyTo(elements, 0);
            }

            foreach (var col in this.elementsArrays.Keys)
            {
                if (!this.seenHashset.Contains(col)) this.toRemoveList.Add(col);
            }

            for (int i = 0; i < this.toRemoveList.Count; i++)
            {
                this.elementsArrays.Remove(this.toRemoveList[i]);
            }
        }

        protected override void Add(TCollection collection, object value)
        {
            collection.Enqueue((TElement)value);
        }

        protected override void Clear(TCollection collection)
        {
            collection.Clear();
        }

        protected override bool CollectionIsReadOnly(TCollection collection)
        {
            return false;
        }

        protected override int GetChildCount(TCollection value)
        {
            return value.Count;
        }

        protected override void Remove(TCollection collection, object value)
        {
            var count = collection.Count;
            var sValue = (TElement)value;

            using (var copyBuffer = Buffer<TElement>.Claim(count))
            {
                var array = copyBuffer.Array;
                collection.CopyTo(array, 0);

                collection.Clear();

                bool hasRemoved = false;

                for (int i = 0; i < count; i++)
                {
                    if (hasRemoved || !EqualityComparer<TElement>.Default.Equals(array[i], sValue))
                    {
                        collection.Enqueue(array[i]);
                    }
                    else
                    {
                        hasRemoved = true;
                    }
                }
            }
        }

        protected override void InsertAt(TCollection collection, int index, object value)
        {
            var count = collection.Count;
            var tValue = (TElement)value;
            using (var copyBuffer = Buffer<TElement>.Claim(count))
            {
                var array = copyBuffer.Array;
                collection.CopyTo(array, 0);

                collection.Clear();

                for (int i = 0; i < count + 1; i++)
                {
                    if (i == index)
                    {
                        collection.Enqueue(tValue);
                    }
                    else
                    {
                        int oldElementIndex;

                        if (i < index) oldElementIndex = i;
                        else oldElementIndex = i - 1;

                        collection.Enqueue(array[oldElementIndex]);
                    }
                }
            }
        }

        protected override void RemoveAt(TCollection collection, int index)
        {
            var count = collection.Count;

            using (var copyBuffer = Buffer<TElement>.Claim(count))
            {
                var array = copyBuffer.Array;
                collection.CopyTo(array, 0);

                collection.Clear();

                for (int i = 0; i < count; i++)
                {
                    if (i != index)
                    {
                        collection.Enqueue(array[i]);
                    }
                }
            }
        }
    }
}
#endif